package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    Thread thread = new Thread() {
        @Override
        public void run() {
            // La vostra crida
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Modificar el TextView
                }
            });


        }

    };
thread.start();
        }




