package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * @author KhaoulaIB
 * Date: 21/02/24
 * Idea: basic calculator. First project on Android Sutdio
 */
public class MainActivity extends AppCompatActivity {

    double firstNum;
    String operand;
    TextView screen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        screen = findViewById(R.id.screen);

        // Asignación de botones numéricos usando bucle
        List<Button> nums = new ArrayList<>();
        for (int i = 0; i <= 9; i++) {
            int id = getResources().getIdentifier("num" + i, "id", getPackageName());
            Button num = findViewById(id);
            nums.add(num);
        }

        // Asignación de botones de operaciones
        List<Button> operands = new ArrayList<>();
        int[] operandIds = {R.id.mult, R.id.add, R.id.min, R.id.equal, R.id.C};
        for (int id : operandIds) {
            Button operandBtn = findViewById(id);
            operands.add(operandBtn);
        }

        // Configuración de Listeners para botones numéricos
        for (Button b : nums) {
            b.setOnClickListener(view -> {
                String buttonText = b.getText().toString();
                if (!screen.getText().toString().equals("0")) {
                    screen.append(buttonText);
                } else {
                    screen.setText(buttonText);
                }
            });
        }

        // Configuración de Listeners para botones de operaciones
        for (Button b : operands) {
            b.setOnClickListener(view -> {
                firstNum = Double.parseDouble(screen.getText().toString());
                operand = b.getText().toString();
                screen.setText("0");
            });
        }

        // Listener para el botón de borrar (C)
        Button clearButton = findViewById(R.id.C);
        clearButton.setOnClickListener(view -> {
                screen.setText("0");

        });

        // Listener para el botón de igual (=)
        Button equalButton = findViewById(R.id.equal);
        equalButton.setOnClickListener(view -> {
            double secondNum = Double.parseDouble(screen.getText().toString());
            double result = 0;
            switch (operand) {
                case "*":
                    result = firstNum * secondNum;
                    break;
                case "+":
                    result = firstNum + secondNum;
                    break;
                case "-":
                    result = firstNum - secondNum;
                    break;
            }
            screen.setText(String.valueOf(result));
            firstNum = result;
        });
    }
}
